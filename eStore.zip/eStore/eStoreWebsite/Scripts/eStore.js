﻿$(function () {
    //click on tab disable click if errors - register popup

    $('#myTabs .nav, nav-tabs').click(function (e) {
        $('#form0').validate();
        if ($('#form0').valid()) {
            return true;
        }
        else {
            return false;
        }
    });//tabs
});//main Jquery function